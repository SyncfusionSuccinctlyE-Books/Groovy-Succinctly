# Groovy Succinctly

This repository contains the code listings for the _Succinctly Groovy_ book.

## Pre-requisites

The code found here was prepared for use with Groovy 2.4.5 and the Java 8 JDK.
